<?php
$lang['findtalents_sidebar_skills']='Kompetens';
$lang['findtalents_sidebar_sub_skills']='Underkunskaper';
$lang['findtalents_sidebar_all']='Allt';
$lang['findtalents_sidebar_membership_plan']='Medlemskapsplan';
$lang['findtalents_sidebar_country']='Land';
$lang['findtalents_sidebar_city']='Stad';
$lang['findtalents_freelancers']='frilansare';
$lang['findtalents_find_talents_by_name']='Hitta talanger med namn';
$lang['findtalents_search']='Sök';
$lang['findtalents_advanced_search']='avancerad sökning';
$lang['findtalents_more']='Mer';
$lang['findtalents_job_success']='Jobsucces';
$lang['findtalents_compleated_projects']='Avslutat projekt';
$lang['findtalents_hr']='hr';
$lang['findtalents_skills']='Kompetens';
$lang['findtalents_skills_not_set_yet']='Skicklighet är inte inställd än';
$lang['findtalents_no_record_found']='No record found';

$lang['findtalents_invalid_freelancer']='Ogiltig Freelancer';
$lang['findtalents_invalid_amount']='Ogiltigt belopp';
$lang['findtalents_insufficient_fund']='Otillräckliga medel';
$lang['findtalents_bonus_sent_to_freelancer_account']='Bonus skickad till frilansarkonto';
$lang['findtalents_amount_not_update_in_freelancer_account']='Beloppet uppdateras inte i Freelancer-kontot';
$lang['findtalents_amount_debited_but_not_added_to_freelancer_account']='Belopp som debiteras men inte läggs till på frilansarkonto';
$lang['findtalents_error_in_update_amount']='Fel i uppdateringsbeloppet';
$lang['findtalents_error_in_debit_amount']='Fel i debiteringsbeloppet';
$lang['findtalents_bonus_not_send_try_again_later']='Bonus inte skickad. Försök igen senare!';
?>