<?php
$lang['forgotpass_new_password_has_been_sent_to_your_email']='Nytt lösenord skickades till ditt mail.';
$lang['forgotpass_to_recover_your_password_end_text']='För att återställa ditt lösenord, ange e-postadressen som är kopplad till ditt konto.';
$lang['forgotpass_email_id']='E-post ID';
$lang['forgotpass_go_back_to']='Gå tillbaka till';
$lang['forgotpass_sign_in']='Logga in';
$lang['forgotpass_submit']='Lämna';
$lang['forgotpass_the_email_address_is_required']='E-postadressen krävs';
$lang['forgotpass_the_input_is_not_a_valid_email_address']='Inmatningen är inte en giltig e-postadress';
$lang['forgotpass_enter_your_email']='Ange din e-postadress';
$lang['forgotpass_sorry_email_address_is_not_found_in_db']='Förlåt! Den här e-postadressen hittades inte i vår databas';
$lang['forgotpass_enter_new_password']='Ange nytt lösenord';
$lang['forgotpass_please_confirm_your_password']='Vänligen bekräfta ditt lösenord';
$lang['forgotpass_confirm_password_does_not_match']='Bekräfta att lösenordet inte matchar';
$lang['forgotpass_password_reset_successful']='Lösenordsåterställning framgångsrikt';
$lang['forgotpass_please']='Snälla du';
$lang['forgotpass_login_in']='logga in';
$lang['forgotpass_to_continue']='Att fortsätta.';
$lang['forgotpass_failed_database_error_occured_please_try_again']='misslyckades! Databasfel inträffat. Var god försök igen.';
$lang['forgotpass_reset_password']='Återställ lösenord';
$lang['forgotpass_confirm_new_password']='Bekräfta nytt lösenord';
?>