<?php
$lang['membership_days']='dagar';
$lang['membership_bids']='bud';
$lang['membership_skills']='Kompetens';
$lang['membership_portfolio']='Portfölj';
$lang['membership_project']='projekt';
$lang['membership_unlimited_days']='Obegränsade dagar';
$lang['membership_auto_renew_at_expiration']='Förnyas automatiskt vid utgången';
$lang['membership_subscription_charge_auto_renew_msg']='Markera den här rutan för att automatiskt förnya din prenumeration vid utgången. Ditt konto debiteras automatiskt. Du kommer att få ett meddelande om ditt konto inte är tillräckligt finansierat.';
$lang['membership_upgrade_membership']='Uppgradera medlemskap';
$lang['membership_do_you_want_to_upgrade_your_plan']='Vill du uppgradera din plan?';
$lang['membership_you_dont_have_enough_balance_add_fund']='Du har inte tillräckligt med balans för att uppgradera medlemskapet. Vänligen lägg till fond';
$lang['membership_subscribed']='prenumererar';
?>