<?php
$lang['message_add_user_to_room']='Lägg till användare till rummet';
$lang['message_choose_users']='Välj användare';
$lang['message_add_users']='Lägg till användare';
$lang['message_close']='Stänga';
$lang['message_favorite_message']='Favoritmeddelande';
$lang['message_search']='Sök';
$lang['message_recent']='Nyligen';
$lang['message_unread']='Oläst';
$lang['message_hide']='Dölj';
$lang['message_no_projects_found']='Inga projekt hittades!';
$lang['message_load_more']='Ladda mer';
$lang['message_favorites']='favoriter';
$lang['message_interviews']='intervjuer';
$lang['message_no_conversation_yet']='Ingen konversation än ..';
$lang['message_files']='filer';
$lang['message_people']='människor';
?>