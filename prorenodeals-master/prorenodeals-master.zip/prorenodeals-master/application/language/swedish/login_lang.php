<?php
$lang['login_sign_in'] ='Logga in';
$lang['login_home'] ='Hem';
$lang['login_username'] ='Användarnamn';
$lang['login_email_id'] ='E-post ID';
$lang['login_password'] ='Lösenord';
$lang['login_remember_me'] ='Kom ihåg mig';
$lang['login_forget_passowrd'] ='Glömt ditt lösenord?';
$lang['login_username_field_required'] ='Användarnamnet eller e-post-id krävs';
$lang['login_username_field_required_cheracter'] ='Användarnamnet måste vara mer än 6 och mindre än 12 tecken långt';
$lang['login_username_field_required_alphabetic_number'] ='Användarnamnet kan bara bestå av alfabetisk, nummer, punkt och understrykning';
$lang['login_password_required'] ='Lösenordet krävs';
$lang['login_password_username_required'] ='Lösenordet kan inte vara detsamma som användarnamnet';
$lang['login_failed_to_login_username_password_wrong'] ='Inloggningen misslyckades! fel användarnamn / e-post eller lösenord eller din profil är inte aktiverad än';
$lang['login_select_one_city'] ='Välj en stad';
?>