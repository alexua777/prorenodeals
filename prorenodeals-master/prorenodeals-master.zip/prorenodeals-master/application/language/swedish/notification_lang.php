<?php
$lang['notification_notification']='anmälningar';
$lang['notification_date']='Datum';
$lang['notification_unread']='oläst';
$lang['notification_are_u_sure_want_to_delete']='Vill du verkligen radera?';
$lang['notification_no_notifivation_found']='Inga meddelanden hittades !!!';
?>