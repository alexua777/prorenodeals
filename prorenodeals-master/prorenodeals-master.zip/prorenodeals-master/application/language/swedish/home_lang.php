<?php
$lang['home_post_job'] = 'post jobb';
$lang['home_register_now'] = 'Registrera nu';

$lang['home_get_more_done_with_freelancer'] = 'Få mer gjort med frilansare';
$lang['home_grow_your_business_with_the_top_freelancing_website'] = 'Utveckla din verksamhet med den bästa freelancingwebbplatsen.';
$lang['home_work_with_someone_perfect_for_your_team'] = 'Arbeta med någon som är perfekt för ditt lag';
$lang['home_see_all_freelancer'] = 'Se all frilansare';
$lang['home_how_it_works'] = 'Hur det fungerar';
$lang['home_find'] = 'Hitta';
$lang['home_find_text'] = 'Sed posuere consectetur est på lobortis. Maecenas sed diam eget risus varius blandat sitt eget non magna. Integer ställer in en ante venenatis dapibus.';
$lang['home_hire'] = 'Hyra';
$lang['home_hire_text'] = 'Morbi leo risus, porta ac consectetur, vestibulum vid eros. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auktor. Duis mollis, est non commodo.';
$lang['home_work'] = 'Arbete';
$lang['home_work_text'] = 'Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auktor. Fästningens ligula porta felis euismod semper. Du kan även boka rum med eget badrum.';
$lang['home_pay'] = 'Betala';
$lang['home_pay_text'] = 'Inbyggd blandad tempusporttitor. Fästningens ligula porta felis euismod semper. Donec id elit non mi porta gravida på egen metus. Duis mollis är inte en vanlig luktus.';
$lang['home_our_plans'] = 'Våra planer';
$lang['home_bids'] = 'bud';
$lang['home_skills'] = 'Kompetens';
$lang['home_portfolio'] = 'Portfölj';
$lang['home_projects'] = 'projekt';
$lang['home_unlimited_days'] = 'Obegränsade dagar';
$lang['home_commission'] = 'Provision';
$lang['home_compare_details'] = 'Jämför detaljer';
$lang['home_what_uor_client_say'] = 'Vad säger vår klient?';
$lang['home_find_out_that_people_say_about_us_text'] = 'Ta reda på vad folk säger om oss och tänk hundratals nöjda kunder.';
$lang['home_top_businesses_hiring_flance'] = 'Topp företag som anställer på Flance';
$lang['home_work_with_someone_perfect_for_your_team'] = 'Arbeta med någon som är perfekt för ditt lag';
$lang['home_browae_top_skills'] = 'Bläddra bland de bästa färdigheterna';
$lang['home_browae_all_skills'] = 'Bläddra bland alla färdigheter';
$lang['home_get_started'] = 'Komma igång';
$lang['home_fantastic_facts'] = 'Fantastiska fakta';
$lang['home_fantastic_facts_text'] = 'Det är viktigt att du är säker på att du ska vara säker på att du inte får tid att ta hand om ditt arbete och att du ska kunna utföra ett annat än vad som helst.';
$lang['home_total_user'] = 'Total användare';
$lang['home_total_projects'] = 'Totala projekt';
$lang['home_total_completed_projects'] = 'Totalt genomförda projekt';
?>