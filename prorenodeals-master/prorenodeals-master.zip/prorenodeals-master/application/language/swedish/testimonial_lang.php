<?php
$lang['testimonial_username']='Användarnamn';
$lang['testimonial_your_feedback']='Din återkoppling';
$lang['testimonial_submit']='Lämna';
$lang['testimonial_feedback']='Återkoppling';
$lang['testimonial_insert_success_text']='Din feedback skickas till successfuly. Samma kommer att läggas upp efter admin verifiering';
$lang['testimonial_unable_to_insert_data']='Det gick inte att infoga data';
?>