<?php
$lang['message_add_user_to_room']='Add users to room';
$lang['message_choose_users']='Choose users';
$lang['message_add_users']='Add Users';
$lang['message_close']='Close';
$lang['message_favorite_message']='Favorite Message';
$lang['message_search']='Search';
$lang['message_recent']='Recent';
$lang['message_unread']='Unread';
$lang['message_hide']='Hide';
$lang['message_no_projects_found']='No Projects found!';
$lang['message_load_more']='Load more';
$lang['message_favorites']='Favorites';
$lang['message_interviews']='Interviews';
$lang['message_no_conversation_yet']='No conversation yet..';
$lang['message_files']='Files';
$lang['message_people']='People';
$lang['message_no_file']='No file';
?>