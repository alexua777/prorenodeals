<?php

$lang['findjob_sidebar_category']='Category';

$lang['findjob_sidebar_sub_category']='Sub Category';

$lang['findjob_sidebar_project_type']='Project Type';

$lang['findjob_sidebar_featured_project']='Featured Project';

$lang['findjob_sidebar_project_environment']='Project Environment';

$lang['findjob_sidebar_all']='All';

$lang['findjob_sidebar_online']='On line';

$lang['findjob_sidebar_offline']='Off line';

$lang['findjob_sidebar_budget']='Budget';

$lang['findjob_sidebar_to']='to';

$lang['findjob_sidebar_submit']='Submit';

$lang['findjob_sidebar_posted_within']='Posted within';

$lang['findjob_sidebar_posted_within_24_hours']='Posted within 24 hours';

$lang['findjob_sidebar_posted_within_3_days']='Posted within 3 days';

$lang['findjob_sidebar_posted_within_7_days']='Posted within 7 days';

$lang['findjob_sidebar_country']='Country';

$lang['findjob_sidebar_featured']='Featured';

$lang['findjob_sidebar_non_featured']='Non-Featured';

$lang['findjob_sidebar_hourly']='Hourly';

$lang['findjob_sidebar_fixed']='Fixed';



$lang['findjob_find_job']='Find Jobs';

$lang['findjob_search']='Search';

$lang['findjob_advance_search']='Advanced Search';

$lang['findjob_search_job_by_title']='Search job by title';

$lang['findjob_featured']='Featured';

$lang['findjob_hourly']='Hourly';

$lang['findjob_fixed']='Fixed';

$lang['findjob_price']='Price';

$lang['findjob_between']='Between';

$lang['findjob_and']='and';

$lang['findjob_posted']='Posted';

$lang['findjob_proposals']='Proposals';

$lang['findjob_more']='more';

$lang['findjob_skills']='Skills';

$lang['findjob_category']='Category';

$lang['findjob_posted_by']='Posted by';

$lang['findjob_select_this_job']='Select this job';

$lang['findjob_no_jobs_found']='No jobs found';

?>