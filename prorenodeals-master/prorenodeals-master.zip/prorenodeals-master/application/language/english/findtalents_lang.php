<?php
$lang['findtalents_sidebar_skills']='Skills';
$lang['findtalents_sidebar_sub_skills']='Sub Skills';
$lang['findtalents_sidebar_all']='All';
$lang['findtalents_sidebar_membership_plan']='Membership Plan';
$lang['findtalents_sidebar_country']='Country';
$lang['findtalents_sidebar_city']='City';

$lang['findtalents_freelancers']='Freelancers';
$lang['findtalents_find_talents_by_name']='Find talents by name';
$lang['findtalents_search']='Search';
$lang['findtalents_advanced_search']='Advanced Search';
$lang['findtalents_more']='more';
$lang['findtalents_job_success']='Job Success';
$lang['findtalents_compleated_projects']='Completed Project';
$lang['findtalents_hr']='hr';
$lang['findtalents_skills']='Skills';
$lang['findtalents_skills_not_set_yet']='Skill Not Set Yet';
$lang['findtalents_no_record_found']='No record found';

$lang['findtalents_invalid_freelancer']='Invalid Freelancer';
$lang['findtalents_invalid_amount']='Invalid Amount';
$lang['findtalents_insufficient_fund']='Insufficient fund';
$lang['findtalents_bonus_sent_to_freelancer_account']='Bonus sent to freelancer account';
$lang['findtalents_amount_not_update_in_freelancer_account']='Amount not update in Freelancer account';
$lang['findtalents_amount_debited_but_not_added_to_freelancer_account']='Amount debited but not added to freelancer account';
$lang['findtalents_error_in_update_amount']='Error in update amount';
$lang['findtalents_error_in_debit_amount']='Error in debit amount';
$lang['findtalents_bonus_not_send_try_again_later']='Bonus not sent. Try again later!';
?>