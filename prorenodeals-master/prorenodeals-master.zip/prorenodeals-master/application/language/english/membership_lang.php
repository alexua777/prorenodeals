<?php
$lang['membership_days']='Days';
$lang['membership_bids']='Bids';
$lang['membership_skills']='Skills';
$lang['membership_portfolio']='Portfolio';
$lang['membership_project']='Projects';
$lang['membership_unlimited_days']='Unlimited Days';
$lang['membership_auto_renew_at_expiration']='Auto-renew at expiration';
$lang['membership_subscription_charge_auto_renew_msg']='Please check this box to auto-renew your subscription at expiration. Your account will be charged automatically. You will receive a message if your account is not sufficiently funded.';
$lang['membership_upgrade_membership']='Upgrade Membership';
$lang['membership_do_you_want_to_upgrade_your_plan']='Do you want to upgrade your plan?';
$lang['membership_you_dont_have_enough_balance_add_fund']='You don\'t have enough balance to upgrade membership. Please add fund';
$lang['membership_balance']='Balance';
$lang['membership_thank_you_your_membership_upgrate_successfully']='Thank you. Your Membership Upgrade Successfully...';
$lang['membership_subscribed']='Subscribed';
?>