<?php

$lang['hello'] = 'Ritesh';

$lang['language'] = 'English';

$lang['find_job'] = 'Find jobs';

$lang['post_job'] = 'Post job';

$lang['find_freelancer'] = 'Find freelancer';

$lang['message'] = 'Messages';

$lang['dashboard'] = 'Dashboard';

$lang['logout'] = 'Logout';

$lang['freelancer'] = 'Freelancer';

$lang['jobs'] = 'Jobs';

$lang['search'] = 'Search';

$lang['register'] = 'Register';

$lang['login'] = 'Login';

$lang['signin'] = 'Sign in';

$lang['popular_links'] = 'Popular Links';

$lang['about_us'] = 'About Us';

$lang['success_tips'] = 'Success Tips';

$lang['terms_&_conditions'] = 'Terms & Conditions';

$lang['service_provider_agreement'] = 'Service Provider Agreement';

$lang['refund_policy'] = 'Refund Policy';

$lang['privecy_policy'] = 'Privacy Policy';

$lang['faqs'] = 'FAQs';

$lang['sitemap'] = 'Sitemap';

$lang['contact_us'] = 'Contact Us';

$lang['browse'] = 'Browse';

$lang['subscribe_to_newsletter'] = 'Subscribe to Newsletter';

$lang['subscribe_our_newsletter_to_get_reguler_update'] = 'Please subscribe our newsletter to get regular update';

$lang['enter_your_email'] = 'Enter your email';

$lang['subscribe'] = 'Subscribe';

$lang['subscription_successful'] = 'Thank you. Your newsletter subscription is successful.';

$lang['subscription_failed'] = 'Sorry..! Unable to process your request.';

$lang['alert_email_exist'] = 'Sorry..! This Email Id already exist.';

$lang['alert_valid_email'] = 'Enter a valid email.';

$lang['email_address'] = 'Email Address';

$lang['home'] = 'Home';

$lang['signup'] = 'Signup';

$lang['find_job'] = 'Find Job';

$lang['pagination_first'] = 'First';

$lang['pagination_previous'] = 'Previous';

$lang['pagination_next'] = 'Next';

$lang['pagination_last'] = 'Last';



$lang['jan'] = 'Jan';

$lang['feb'] = 'Feb';

$lang['mar'] = 'Mar';

$lang['apr'] = 'Apr';

$lang['may'] = 'May';

$lang['jun'] = 'Jun';

$lang['jul'] = 'Jul';

$lang['aug'] = 'Aug';

$lang['sep'] = 'Sep';

$lang['oct'] = 'Oct';

$lang['nov'] = 'Nov';

$lang['dec'] = 'Dec';



$lang['find_talent']='Find Talent';

$lang['my_project']='My Projects';

$lang['my_finance']='My Finance';

$lang['my_milestone']='My Milestone';

$lang['membership']='Membership';

$lang['rating']='Rating';

$lang['notification']='Notification';

$lang['job_details']='Job Details';

$lang['forgot_password']='Forgot Password';



?>