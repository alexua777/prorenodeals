<?php
$lang['login_sign_in'] ='Sign in';
$lang['login_home'] ='Home';
$lang['login_username'] ='Username';
$lang['login_email_id'] ='Email ID';
$lang['login_password'] ='Password';
$lang['login_remember_me'] ='Remember Me';
$lang['login_forget_passowrd'] ='Forgot Password?';
$lang['login_username_field_required'] ='The username or email id is required';
$lang['login_username_field_required_cheracter'] ='The username must be more than 6 and less than 12 characters long';
$lang['login_username_field_required_alphabetic_number'] ='The username can only consist of alphabetical, number, dot and underscore';
$lang['login_password_required'] ='The password is required';
$lang['login_password_username_required'] ='The password cannot be the same as username';
$lang['login_failed_to_login_username_password_wrong'] ='Login failed! wrong username/email or password or your profile is not activated yet';
$lang['login_select_one_city'] ='Select one city';
?>