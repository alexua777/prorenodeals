<?php
$lang['notification_notification']='Notifications';
$lang['notification_date']='Date';
$lang['notification_unread']='unread';
$lang['notification_are_u_sure_want_to_delete']='Are you sure want to delete?';
$lang['notification_no_notifivation_found']='No Notifications found !!!';
?>