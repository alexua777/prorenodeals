<?php
$lang['testimonial_username']='Username';
$lang['testimonial_your_feedback']='Your Feedback';
$lang['testimonial_submit']='Submit';
$lang['testimonial_feedback']='Feedback';
$lang['testimonial_insert_success_text']='Your feedback is submitted successfuly. Same will be posted after admin verification';
$lang['testimonial_unable_to_insert_data']='Unable to Insert Data';
?>