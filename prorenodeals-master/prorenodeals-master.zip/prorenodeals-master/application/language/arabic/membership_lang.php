<?php
$lang['membership_days']='أيام';
$lang['membership_bids']='العروض';
$lang['membership_skills']='مهارات';
$lang['membership_portfolio']='محفظة';
$lang['membership_project']='مشاريع';
$lang['membership_unlimited_days']='أيام غير محدودة';
$lang['membership_auto_renew_at_expiration']='التجديد التلقائي عند انتهاء الصلاحية';
$lang['membership_subscription_charge_auto_renew_msg']='يرجى تحديد هذا المربع لتجديد اشتراكك تلقائيا عند انتهاء صلاحيته. سيتم تحصيل الرسوم من حسابك تلقائيا. ستتلقى رسالة إذا لم يتم تمويل حسابك بشكل كاف.';
$lang['membership_upgrade_membership']='ترقية العضوية';
$lang['membership_do_you_want_to_upgrade_your_plan']='هل تريد ترقية خطتك؟';
$lang['membership_you_dont_have_enough_balance_add_fund']='لم يكن لديك رصيد كاف لترقية العضوية. يرجى إضافة صندوق';
$lang['membership_subscribed']='المشترك';
?>