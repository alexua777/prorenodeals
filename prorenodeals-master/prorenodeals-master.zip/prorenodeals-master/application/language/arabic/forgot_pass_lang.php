<?php
$lang['forgotpass_new_password_has_been_sent_to_your_email']='تم إرسال كلمة مرور جديدة إلى بريدك الإلكتروني.';
$lang['forgotpass_to_recover_your_password_end_text']='لاستعادة كلمة المرور، أدخل عنوان البريد الإلكتروني المقترن بحسابك.';
$lang['forgotpass_email_id']='عنوان الايميل';
$lang['forgotpass_go_back_to']='ارجع الى';
$lang['forgotpass_sign_in']='تسجيل الدخول';
$lang['forgotpass_submit']='خضع';
$lang['forgotpass_the_email_address_is_required']='عنوان البريد الإلكتروني مطلوب';
$lang['forgotpass_the_input_is_not_a_valid_email_address']='الإدخال ليس عنوان بريد إلكتروني صالحا';
$lang['forgotpass_enter_your_email']='أدخل بريدك الإلكتروني';
$lang['forgotpass_sorry_email_address_is_not_found_in_db']='آسف! لم يتم العثور على عنوان البريد الإلكتروني هذا في قاعدة البيانات الخاصة بنا';
$lang['forgotpass_enter_new_password']='أدخل كلمة مرور جديدة';
$lang['forgotpass_please_confirm_your_password']='يرجى التأكد من صحة كلمة المرور الخاصة بك';
$lang['forgotpass_confirm_password_does_not_match']='تأكيد عدم مطابقة كلمة المرور';
$lang['forgotpass_password_reset_successful']='إعادة تعيين كلمة المرور بنجاح';
$lang['forgotpass_please']='رجاء';
$lang['forgotpass_login_in']='تسجيل الدخول';
$lang['forgotpass_to_continue']='لاستكمال.';
$lang['forgotpass_failed_database_error_occured_please_try_again']='فشل! حدث خطأ في قاعدة البيانات. حاول مرة اخرى.';
$lang['forgotpass_reset_password']='إعادة تعيين كلمة المرور';
$lang['forgotpass_confirm_new_password']='تأكيد كلمة المرور الجديدة';
?>