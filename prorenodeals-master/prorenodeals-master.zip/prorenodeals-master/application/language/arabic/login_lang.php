<?php
$lang['login_sign_in'] ='تسجيل الدخول';
$lang['login_home'] ='الصفحة الرئيسية';
$lang['login_username'] ='اسم المستخدم';
$lang['login_email_id'] ='عنوان الايميل';
$lang['login_password'] ='كلمه السر';
$lang['login_remember_me'] ='تذكرنى';
$lang['login_forget_passowrd'] ='هل نسيت كلمة المرور؟';
$lang['login_username_field_required'] ='مطلوب اسم المستخدم أو معرف البريد الإلكتروني';
$lang['login_username_field_required_cheracter'] ='يجب أن يكون اسم المستخدم أكثر من 6 وأقل من 12 حرفا';
$lang['login_username_field_required_alphabetic_number'] ='يمكن أن يتكون اسم المستخدم فقط من أبجدي، عدد، نقطة ونقطة سفلية';
$lang['login_password_required'] ='كلمة المرور مطلوبة';
$lang['login_password_username_required'] ='لا يمكن أن تكون كلمة المرور هي نفس اسم المستخدم';
$lang['login_failed_to_login_username_password_wrong'] ='فشل تسجيل الدخول! اسم المستخدم / البريد الإلكتروني أو كلمة المرور الخاطئة أو لم يتم تنشيط ملفك الشخصي بعد';
$lang['login_select_one_city'] ='حدد مدينة واحدة';
?>