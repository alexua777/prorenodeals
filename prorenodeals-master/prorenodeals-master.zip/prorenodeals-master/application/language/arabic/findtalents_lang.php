<?php
$lang['findtalents_sidebar_skills']='مهارات';
$lang['findtalents_sidebar_sub_skills']='المهارات الفرعية';
$lang['findtalents_sidebar_all']='الكل';
$lang['findtalents_sidebar_membership_plan']='خطة العضوية';
$lang['findtalents_sidebar_country']='بلد';
$lang['findtalents_sidebar_city']='مدينة';
$lang['findtalents_freelancers']='أعمال حرة';
$lang['findtalents_find_talents_by_name']='البحث عن المواهب بالاسم';
$lang['findtalents_search']='بحث';
$lang['findtalents_advanced_search']='البحث المتقدم';
$lang['findtalents_more']='أكثر من';
$lang['findtalents_job_success']='النجاح الوظيفي';
$lang['findtalents_compleated_projects']='المشروع المنجز';
$lang['findtalents_hr']='ساعة';
$lang['findtalents_skills']='مهارات';
$lang['findtalents_skills_not_set_yet']='لم يتم تحديد المهارات بعد';
$lang['findtalents_no_record_found']='لا يوجد سجلات';

$lang['findtalents_invalid_freelancer']='فريلانسر غير صالح';
$lang['findtalents_invalid_amount']='مبلغ غير صحيح';
$lang['findtalents_insufficient_fund']='تمويل غير كاف';
$lang['findtalents_bonus_sent_to_freelancer_account']='مكافأة أرسلت إلى حساب لحسابهم الخاص';
$lang['findtalents_amount_not_update_in_freelancer_account']='لم يتم تحديث المبلغ في حساب فريلانسر';
$lang['findtalents_amount_debited_but_not_added_to_freelancer_account']='المبلغ الخصم ولكن لم تضاف إلى حساب لحسابهم الخاص';
$lang['findtalents_error_in_update_amount']='حدث خطأ في تحديث المبلغ';
$lang['findtalents_error_in_debit_amount']='خطأ في مبلغ الخصم';
$lang['findtalents_bonus_not_send_try_again_later']='لم يتم إرسال المكافأة. حاول مرة أخرى في وقت لاحق!';
?>