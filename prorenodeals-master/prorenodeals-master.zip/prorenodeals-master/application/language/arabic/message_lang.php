<?php
$lang['message_add_user_to_room']='إضافة مستخدمين إلى الغرفة';
$lang['message_choose_users']='اختر المستخدمين';
$lang['message_add_users']='إضافة مستخدمين';
$lang['message_close']='قريب';
$lang['message_favorite_message']='الرسالة المفضلة';
$lang['message_search']='بحث';
$lang['message_recent']='الأخيرة';
$lang['message_unread']='غير مقروء';
$lang['message_hide']='إخفاء';
$lang['message_no_projects_found']='لم يتم العثور على مشاريع!';
$lang['message_load_more']='تحميل المزيد';
$lang['message_favorites']='المفضلة';
$lang['message_interviews']='مقابلات';
$lang['message_no_conversation_yet']='لا محادثة حتى الآن ..';
$lang['message_files']='ملفات';
$lang['message_people']='اشخاص';
?>