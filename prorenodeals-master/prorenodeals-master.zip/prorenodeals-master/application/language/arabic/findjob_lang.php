<?php
$lang['findjob_sidebar_category']='الفئة';
$lang['findjob_sidebar_sub_category']='الفئة الفرعية';
$lang['findjob_sidebar_project_type']='نوع المشروع';
$lang['findjob_sidebar_featured_project']='مشروع مميز';
$lang['findjob_sidebar_project_environment']='بيئة المشروع';
$lang['findjob_sidebar_all']='الكل';
$lang['findjob_sidebar_online']='عبر الانترنت';
$lang['findjob_sidebar_offline']='غير متصل على الانترنت';
$lang['findjob_sidebar_budget']='ميزانية';
$lang['findjob_sidebar_to']='إلى';
$lang['findjob_sidebar_submit']='خضع';
$lang['findjob_sidebar_posted_within']='نشرت خلال';
$lang['findjob_sidebar_posted_within_24_hours']='نشرت في غضون 24 ساعة';
$lang['findjob_sidebar_posted_within_3_days']='نشرت خلال 3 أيام';
$lang['findjob_sidebar_posted_within_7_days']='تم نشرها خلال 7 أيام';
$lang['findjob_sidebar_country']='بلد';
$lang['findjob_sidebar_featured']='متميز';
$lang['findjob_sidebar_non_featured']='غير المميز';
$lang['findjob_sidebar_hourly']='باستمرار';
$lang['findjob_sidebar_fixed']='ثابت';

$lang['findjob_find_job']='البحث عن وظيفة';
$lang['findjob_search']='بحث';
$lang['findjob_advance_search']='البحث المتقدم';
$lang['findjob_search_job_by_title']='البحث عن وظيفة حسب العنوان';
$lang['findjob_featured']='متميز';
$lang['findjob_hourly']='باستمرار';
$lang['findjob_fixed']='ثابت';
$lang['findjob_price']='السعر';
$lang['findjob_between']='ما بين';
$lang['findjob_and']='و';
$lang['findjob_posted']='نشر';
$lang['findjob_proposals']='اقتراحات';
$lang['findjob_more']='أكثر من';
$lang['findjob_skills']='مهارات';
$lang['findjob_category']='الفئة';
$lang['findjob_posted_by']='منشور من طرف';
$lang['findjob_select_this_job']='حدد هذه الوظيفة';
$lang['findjob_no_jobs_found']='لم يتم العثور على وظائف';

?>