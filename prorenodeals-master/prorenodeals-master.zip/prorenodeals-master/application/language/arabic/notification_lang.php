<?php
$lang['notification_notification']='إخطارات';
$lang['notification_date']='تاريخ';
$lang['notification_unread']='غير مقروء';
$lang['notification_are_u_sure_want_to_delete']='هل تريد بالتأكيد حذفها؟';
$lang['notification_no_notifivation_found']='لم يتم العثور على إشعارات !!!';
?>