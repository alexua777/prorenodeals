<?php
$lang['testimonial_username']='اسم المستخدم';
$lang['testimonial_your_feedback']='تعليقاتك';
$lang['testimonial_submit']='خضع';
$lang['testimonial_feedback']='ردود الفعل';
$lang['testimonial_insert_success_text']='تم إرسال تعليقاتك بنجاح. سيتم نشر نفسه بعد التحقق من المشرف';
$lang['testimonial_unable_to_insert_data']='يتعذر إدراج البيانات';
?>