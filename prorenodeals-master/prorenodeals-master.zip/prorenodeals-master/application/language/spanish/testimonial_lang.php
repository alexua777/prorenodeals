<?php
$lang['testimonial_username']='Nombre de usuario';
$lang['testimonial_your_feedback']='Tu retroalimentación';
$lang['testimonial_submit']='Enviar';
$lang['testimonial_feedback']='Realimentación';
$lang['testimonial_insert_success_text']='Sus comentarios se enviaron con éxito. Lo mismo se publicará después de la verificación del administrador';
$lang['testimonial_unable_to_insert_data']='No se pueden insertar datos';
?>