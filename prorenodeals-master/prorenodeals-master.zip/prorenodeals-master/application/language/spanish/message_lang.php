<?php
$lang['message_add_user_to_room']='Agregar usuarios a la sala';
$lang['message_choose_users']='Elige usuarios';
$lang['message_add_users']='Agregar usuarios';
$lang['message_close']='Cerca';
$lang['message_favorite_message']='Mensaje favorito';
$lang['message_search']='Buscar';
$lang['message_recent']='Reciente';
$lang['message_unread']='No leído';
$lang['message_hide']='Esconder';
$lang['message_no_projects_found']='No se encontraron proyectos!';
$lang['message_load_more']='Carga más';
$lang['message_favorites']='Favoritos';
$lang['message_interviews']='Entrevistas';
$lang['message_no_conversation_yet']='No hay conversación todavía ...';
$lang['message_files']='Archivos';
$lang['message_people']='Gente';
?>