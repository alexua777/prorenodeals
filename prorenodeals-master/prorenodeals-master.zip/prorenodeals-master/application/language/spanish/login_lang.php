<?php
$lang['login_sign_in'] ='Registrarse';
$lang['login_home'] ='Casa';
$lang['login_username'] ='Nombre de usuario';
$lang['login_email_id'] ='Identificación de correo';
$lang['login_password'] ='Contraseña';
$lang['login_remember_me'] ='Recuérdame';
$lang['login_forget_passowrd'] ='¿Se te olvidó tu contraseña?';
$lang['login_username_field_required'] ='El nombre de usuario o ID de correo electrónico es obligatorio';
$lang['login_username_field_required_cheracter'] ='El nombre de usuario debe tener más de 6 y menos de 12 caracteres de largo';
$lang['login_username_field_required_alphabetic_number'] ='El nombre de usuario solo puede consistir en alfabético, número, punto y guión bajo';
$lang['login_password_required'] ='La contraseña es obligatoria';
$lang['login_password_username_required'] ='La contraseña no puede ser igual que el nombre de usuario';
$lang['login_failed_to_login_username_password_wrong'] ='¡Error de inicio de sesion! nombre de usuario / correo electrónico o contraseña incorrectos o su perfil aún no está activado';
$lang['login_select_one_city'] ='Seleccione una ciudad';
?>