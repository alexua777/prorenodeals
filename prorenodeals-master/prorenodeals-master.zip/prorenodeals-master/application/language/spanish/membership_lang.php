<?php
$lang['membership_days']='Dias';
$lang['membership_bids']='Ofertas';
$lang['membership_skills']='Habilidades';
$lang['membership_portfolio']='portafolio';
$lang['membership_project']='Proyectos';
$lang['membership_unlimited_days']='Días ilimitados';
$lang['membership_auto_renew_at_expiration']='Renovación automática al vencimiento';
$lang['membership_subscription_charge_auto_renew_msg']='Marque esta casilla para renovar automáticamente su suscripción al vencimiento. Su cuenta será cargada automáticamente. Recibirá un mensaje si su cuenta no cuenta con fondos suficientes.';
$lang['membership_upgrade_membership']='Membresía de actualización';
$lang['membership_do_you_want_to_upgrade_your_plan']='¿Quieres actualizar tu plan?';
$lang['membership_you_dont_have_enough_balance_add_fund']='No tienes saldo suficiente para mejorar la membresía. Por favor agregue fondo';
$lang['membership_subscribed']='Suscrito';
?>