<?php
$lang['findtalents_sidebar_skills']='Habilidades';
$lang['findtalents_sidebar_sub_skills']='Sub Habilidades';
$lang['findtalents_sidebar_all']='Todas';
$lang['findtalents_sidebar_membership_plan']='Plan de Membresía';
$lang['findtalents_sidebar_country']='País';
$lang['findtalents_sidebar_city']='Ciudad';
$lang['findtalents_freelancers']='Freelance';
$lang['findtalents_find_talents_by_name']='Encuentra talentos por nombre';
$lang['findtalents_search']='Buscar';
$lang['findtalents_advanced_search']='Búsqueda Avanzada';
$lang['findtalents_more']='Más';
$lang['findtalents_job_success']='Éxito laboral';
$lang['findtalents_compleated_projects']='Proyecto completado';
$lang['findtalents_hr']='hora';
$lang['findtalents_skills']='Habilidades';
$lang['findtalents_skills_not_set_yet']='Habilidad no establecida todavía';
$lang['findtalents_no_record_found']='Ningún record fue encontrado';

$lang['findtalents_invalid_freelancer']='Freelancer inválido';
$lang['findtalents_invalid_amount']='Monto invalido';
$lang['findtalents_insufficient_fund']='Fondos insuficientes';
$lang['findtalents_bonus_sent_to_freelancer_account']='Bonificación enviada a la cuenta de un profesional independiente';
$lang['findtalents_amount_not_update_in_freelancer_account']='La cantidad no se actualiza en la cuenta de Freelancer';
$lang['findtalents_amount_debited_but_not_added_to_freelancer_account']='Cantidad debitada pero no agregada a la cuenta de un profesional independiente';
$lang['findtalents_error_in_update_amount']='Error en la cantidad de actualización';
$lang['findtalents_error_in_debit_amount']='Error en la cantidad de débito';
$lang['findtalents_bonus_not_send_try_again_later']='Bonificación no enviada. ¡Inténtalo más tarde!';
?>