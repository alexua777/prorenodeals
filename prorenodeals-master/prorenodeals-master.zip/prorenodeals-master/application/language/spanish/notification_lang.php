<?php
$lang['notification_notification']='Notificaciones';
$lang['notification_date']='Fecha';
$lang['notification_unread']='no leído';
$lang['notification_are_u_sure_want_to_delete']='¿Estás seguro de querer eliminar?';
$lang['notification_no_notifivation_found']='¡No se encontraron notificaciones!';
?>