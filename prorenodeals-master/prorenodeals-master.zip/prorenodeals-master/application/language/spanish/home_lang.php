<?php
$lang['home_post_job'] = 'trabajo posterior';
$lang['home_register_now'] = 'Regístrate ahora';

$lang['home_get_more_done_with_freelancer'] = 'Haz más cosas con autónomos';
$lang['home_grow_your_business_with_the_top_freelancing_website'] = 'Haga crecer su negocio con el sitio web freelancing superior.';
$lang['home_work_with_someone_perfect_for_your_team'] = 'Trabaja con alguien perfecto para tu equipo';
$lang['home_see_all_freelancer'] = 'Ver todos los Freelancer';
$lang['home_how_it_works'] = 'Cómo funciona';
$lang['home_find'] = 'Encontrar';
$lang['home_find_text'] = 'Sed posuere consectetur est at lobortis. Maecenas sed diam eget risus varius blandit sit amet non magna. Integer posuere erat a ante venenatis dapibus.';
$lang['home_hire'] = 'Alquiler';
$lang['home_hire_text'] = 'Morbi leo risus, porta ac consectetur, vestibulum en eros. Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Duis mollis, est non commodo.';
$lang['home_work'] = 'Trabajo';
$lang['home_work_text'] = 'Vivamus sagittis lacus vel augue laoreet rutrum faucibus dolor auctor. Vestibulum ligula porta felis euismod semper. Cras justo odio, dapibus ac facilidad en, egestas eget quam.';
$lang['home_pay'] = 'Paga';
$lang['home_pay_text'] = 'Curabitur blandit tempus porttitor. Vestibulum ligula porta felis euismod semper. Donec id elit non mi porta gravida en eget metus. Duis mollis, est non commodo luctus.';
$lang['home_our_plans'] = 'Nuestros planes';
$lang['home_bids'] = 'Ofertas';
$lang['home_skills'] = 'Habilidades';
$lang['home_portfolio'] = 'portafolio';
$lang['home_projects'] = 'Proyectos';
$lang['home_unlimited_days'] = 'Días ilimitados';
$lang['home_commission'] = 'Comisión';
$lang['home_compare_details'] = 'Comparar los detalles';
$lang['home_what_uor_client_say'] = '¿Qué dice nuestro cliente?';
$lang['home_find_out_that_people_say_about_us_text'] = 'Descubra lo que dice la gente sobre nosotros y piense en cientos de clientes satisfechos.';
$lang['home_top_businesses_hiring_flance'] = 'Las principales empresas que contratan a Flance';
$lang['home_work_with_someone_perfect_for_your_team'] = 'Trabaja con alguien perfecto para tu equipo';
$lang['home_browae_top_skills'] = 'Navega por las mejores habilidades';
$lang['home_browae_all_skills'] = 'Explorar todas las habilidades';
$lang['home_get_started'] = 'Empezar';
$lang['home_fantastic_facts'] = 'Hechos fantásticos';
$lang['home_fantastic_facts_text'] = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore y dolore magna aliqua ut enim ad minim veniam.';
$lang['home_total_user'] = 'Usuario total';
$lang['home_total_projects'] = 'Total de proyectos';
$lang['home_total_completed_projects'] = 'Total de proyectos completados';
?>