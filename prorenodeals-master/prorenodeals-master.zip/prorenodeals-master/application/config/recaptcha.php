<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['recaptcha_public_key'] = "6LdusQgTAAAAAPARWgiEgjQrwrMkbQ0KA8xJomeW";
$config['recaptcha_private_key'] = "6LdusQgTAAAAAIU7SJ0Vxc9Va-TWbm5Kr4_KzKVx";
$config['theme'] = "white"; 
?>