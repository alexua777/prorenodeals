<div class="wrapper">
 <section>
 	
  <div class="contact_lft_area"><!--start lft area--> 
  	<div class="pie_div">
    	<img src="<?php echo base_url();?>assets/images/bar_img.jpg" />
    </div>
  
  </div>  
  
    
 <div class="contact_rht_area"><!--start rht area-->


  <div class="login_btn_area">
  	<div class="log_btn"><a href="<?php echo base_url();?>login/stepone">Login Now</a></div>
  </div>  
   <h3>
   OR<br /><br />
   <span class="pink"><a href="#">Request a Live Demo</a></span></h3>
  
 </div>   
    
    
    
    
 </section>
 

  

</div>
<div class="clear"></div>