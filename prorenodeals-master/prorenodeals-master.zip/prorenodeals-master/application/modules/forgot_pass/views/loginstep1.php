<style>
.register_error p {
   border: 1px dashed #2d9eca;
    color: #ff0000;
    float: left;
    font-family: Arial,Helvetica,sans-serif;
    font-size: 13px;
    margin-bottom: 10px;
    margin-top: 2px;
    padding: 4px 8px;
    width: 184px;
    }
</style>
<div class="wrapper">
 <section>
 
 <div class="logpage1_area"><!--start rht area-->
 <h2>Client Portal</h2>
 <?php
 if($this->session->flashdata('error_msg'))
 {
 ?>
 <h2><?php echo $this->session->flashdata('error_msg');?></h2>
 <?php
 }
 ?>
<form method="post" action="<?php echo base_url();?>login/stepone">
<label>
<p class="login_text_fld_text">Please enter your username</p>
</label>
	<div class="lable_div">
	<label>
    <input type="text" placeholder="Enter email" class="login_text_fld" name="username" value="<?=  set_value('username')?>">
    <div class="register_error"><?php echo form_error('username');?></div>
    </label>
    </div>
    
   <div class="lable_div">
    <input type="submit" value="Submit" name="sub" class="logpage_btns"/>
   </div>
    
  </form>
 </div>   
    
    
    
    
 </section>
 

  

</div>
<div class="clear"></div>