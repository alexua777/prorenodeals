<?=$search_panel?>

<div id="bd_area">
  <div id="container">
    <div id="part_area" style=" margin-top:20px;">
      <h1 class="free_text" style="padding-top:15px;">
        <?=$page_heading?>
      </h1>
      <br />
      <div class="work_text">
        <?=html_entity_decode($contents)?>
      </div>
      <? echo $footerclient_logo;?> </div>
  </div>
</div>
