<?php
echo $user_email;
?>
<a href="<?php echo VPATH;?>dashoard/">Click Here</a>