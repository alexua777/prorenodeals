<?php

echo "here i am in view folder";


?>