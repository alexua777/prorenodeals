# prorenodeals
new design prorenodeals

Make a new Copy of database_sample.php and constant_sample.php file from application/config/ and admin/application/config/
then rename new copy file with database.php and constant.php file and setup your local path and db connection

Note: Do not rename or delete or move database_sample.php and constant_sample.php files from folder.
